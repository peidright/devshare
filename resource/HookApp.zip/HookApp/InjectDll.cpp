#include "StdAfx.h"
#include "psapi.h" 
#include <string>
#include <iostream>
#include <tlhelp32.h>

#pragma comment(lib, "Psapi.lib") 
//-----------------------------------------------
// InjectDll
// Notice: Loads "LibSpy.dll" into the remote process
//		   (via CreateRemoteThread & LoadLibrary)
//
//		Return value:	1 - success;
//						0 - failure;
//
int InjectDll( HANDLE hProcess )
{
	HANDLE hThread;
	char   szLibPath [_MAX_PATH];
	void*  pLibRemote = 0;	// the address (in the remote process) where
							// szLibPath will be copied to;
	DWORD  hLibModule = 0;	// base adress of loaded module (==HMODULE);

	HMODULE hKernel32 = ::GetModuleHandle("Kernel32");

	
	// Get full path of "LibSpy.dll"
	if( !GetModuleFileName( /*hInst*/NULL,szLibPath,_MAX_PATH) )
		return false;
	strcpy( strstr(szLibPath,".exe"),".dll" );


	// 1. Allocate memory in the remote process for szLibPath
	// 2. Write szLibPath to the allocated memory
	pLibRemote = ::VirtualAllocEx( hProcess, NULL, sizeof(szLibPath), MEM_COMMIT, PAGE_READWRITE );
	if( pLibRemote == NULL )
		return false;
	::WriteProcessMemory(hProcess, pLibRemote, (void*)szLibPath,sizeof(szLibPath),NULL);


	// Load "LibSpy.dll" into the remote process 
	// (via CreateRemoteThread & LoadLibrary)
	hThread = ::CreateRemoteThread( hProcess, NULL, 0,	
					(LPTHREAD_START_ROUTINE) ::GetProcAddress(hKernel32,"LoadLibraryA"), 
					pLibRemote, 0, NULL );
	if( hThread == NULL )
		goto JUMP;

	::WaitForSingleObject( hThread, INFINITE );

	// Get handle of loaded module
	::GetExitCodeThread( hThread, &hLibModule );
	::CloseHandle( hThread );

JUMP:	
	::VirtualFreeEx( hProcess, pLibRemote, sizeof(szLibPath), MEM_RELEASE );
	if( hLibModule == NULL )
		return false;
	
/*
	// Unload "LibSpy.dll" from the remote process 
	// (via CreateRemoteThread & FreeLibrary)
	hThread = ::CreateRemoteThread( hProcess,
                NULL, 0,
                (LPTHREAD_START_ROUTINE) ::GetProcAddress(hKernel32,"FreeLibrary"),
                (void*)hLibModule,
                 0, NULL );
	if( hThread == NULL )	// failed to unload
		return false;

	::WaitForSingleObject( hThread, INFINITE );
	::GetExitCodeThread( hThread, &hLibModule );
	::CloseHandle( hThread );
*/

	// return value of remote FreeLibrary (=nonzero on success)
	return hLibModule;
}

int FreeDll( HANDLE hProcess,DWORD  hLibModule)
{
	HANDLE hThread;

	HMODULE hKernel32 = ::GetModuleHandle("Kernel32");

	hThread = ::CreateRemoteThread( hProcess,
		NULL, 0,
		(LPTHREAD_START_ROUTINE) ::GetProcAddress(hKernel32,"FreeLibrary"),
		(void*)hLibModule,
		0, NULL );
	if( hThread == NULL )	// failed to unload
		return false;
	
	::WaitForSingleObject( hThread, INFINITE );
	::GetExitCodeThread( hThread, &hLibModule );
	::CloseHandle( hThread );

	return hLibModule;
}

/************************************************************************************************************
* �� �� ����UnInjectDll

* ��    ����[in] const TCHAR* pszDllFile // Dll �ļ�����·��
    [in] DWORD dwProcessId    // Ŀ����� ID

* �� �� ֵ��bool - ж�سɹ����� true��ж��ʧ���򷵻� false

* ʵ�ֹ��ܣ���Ŀ�������ж��һ��ָ�� Dll ģ���ļ���
************************************************************************************************************/
bool UnInjectDll(const TCHAR* pszDllFile, DWORD dwProcessId)
{
	// ������Ч
	if (NULL == pszDllFile || 0 == ::_tcslen(pszDllFile))
	{
	   return false;
	}

	HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
	HANDLE hProcess = NULL;
	HANDLE hThread   = NULL;

	// ��ȡģ�����
	hModuleSnap = ::CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwProcessId);
	if (INVALID_HANDLE_VALUE == hModuleSnap)
	{
	   return false;
	}

	MODULEENTRY32 me32;
	memset(&me32, 0, sizeof(MODULEENTRY32));
	me32.dwSize = sizeof(MODULEENTRY32);

	// ��ʼ����
	if(FALSE == ::Module32First(hModuleSnap, &me32))
	{
	   ::CloseHandle(hModuleSnap);
	   return false;
	}

	// ��������ָ��ģ��
	bool isFound = false;
	do
	{
	   isFound = (0 == ::_tcsicmp(me32.szModule, pszDllFile) || 0 == ::_tcsicmp(me32.szExePath, pszDllFile));
	   if (isFound) // �ҵ�ָ��ģ��
	   {
		break;
	   }
	} while (TRUE == ::Module32Next(hModuleSnap, &me32));

	::CloseHandle(hModuleSnap);

	if (false == isFound)
	{
	   return false;
	}

	// ��ȡĿ����̾��
	hProcess = ::OpenProcess(PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION, FALSE, dwProcessId);
	if (NULL == hProcess)
	{
	   return false;
	}

	// �� Kernel32.dll �л�ȡ FreeLibrary ������ַ
	LPTHREAD_START_ROUTINE lpThreadFun = (PTHREAD_START_ROUTINE)::GetProcAddress(::GetModuleHandle(_T("Kernel32")), "FreeLibrary");
	if (NULL == lpThreadFun)
	{
	   ::CloseHandle(hProcess);
	   return false;
	}

	// ����Զ���̵߳��� FreeLibrary
	hThread = ::CreateRemoteThread(hProcess, NULL, 0, lpThreadFun, me32.modBaseAddr /* ģ���ַ */, 0, NULL);
	if (NULL == hThread)
	{
	   ::CloseHandle(hProcess);
	   return false;
	}

	// �ȴ�Զ���߳̽���
	::WaitForSingleObject(hThread, INFINITE);

	// ����
	::CloseHandle(hThread);
	::CloseHandle(hProcess);

	return true;
}

//�������̷���Ȩ�� 
void enableDebugPriv() 
{ 
	HANDLE hToken; 
	LUID sedebugnameValue; 
	TOKEN_PRIVILEGES tkp; 

	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
		return; 

	if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &sedebugnameValue)) { 
		CloseHandle(hToken); 
		return; 
	}

	tkp.PrivilegeCount = 1; 
	tkp.Privileges[0].Luid = sedebugnameValue; 
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 

	if (!AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), NULL, NULL)) 
		CloseHandle(hToken); 
} 

//���ݽ�������ȡ�ý���ID,����ж������ʵ���򷵻ص�һ��ö�ٳ����Ľ���ID 
DWORD getSpecifiedProcessId(const char* pszProcessName) 
{ 
    DWORD processId[1024], cbNeeded, dwProcessesCount; 
    HANDLE hProcess; 
    HMODULE hMod; 
	
    char szProcessName[MAX_PATH] = "UnknownProcess"; 
    DWORD dwArrayInBytes = sizeof(processId)*sizeof(DWORD); 
	
    if (!EnumProcesses(processId, dwArrayInBytes, &cbNeeded)) 
        return 0; 
    //���������е�Ԫ�ظ���
    dwProcessesCount = cbNeeded / sizeof(DWORD); 
    enableDebugPriv(); 
	
    for (UINT i = 0; i < dwProcessesCount; i++) { 
        hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId[i]); 
        if (!hProcess) { 
            continue; 
        } else { 
            if (EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeeded)) { 
                GetModuleBaseName(hProcess, hMod, szProcessName, sizeof(szProcessName)); 
                if (!_stricmp(szProcessName, pszProcessName)) { 
                    CloseHandle(hProcess); 
                    return processId[i]; 
                } 
            } 
        } 
    } 
	
    CloseHandle(hProcess); 
    return 0; 
}