/////////////////////////////////////////////////////////////////////////
//
// hookapi.c
//
// Date   : 04/18/99
//
// oshj add 20040916 ����Щ�ֳɵĺ�����ˬ��ԭ���ߺ����Ǹ�̨��ͬ��
//
/////////////////////////////////////////////////////////////////////////
#include "StdAfx.h"
//#include <windows.h>
#include "hookapi.h"
//#include "string.h"

//#pragma comment(lib, "k32lib.lib")

//extern BOOL g_bCanWrite;

/////////////////////////////////////////////////////////////////////////
// Hook Api
/////////////////////////////////////////////////////////////////////////
FARPROC WINAPI NHGetFuncAddress(HINSTANCE hInst, LPCSTR lpMod, LPCSTR lpFunc)
{
	HMODULE hMod;
	FARPROC procFunc;

	if (NULL != lpMod)
	{
		hMod=GetModuleHandle(lpMod);
		procFunc = GetProcAddress(hMod,lpFunc);
	}
	else
	{
		procFunc = GetProcAddress(hInst,lpFunc);

	}
	
	return  procFunc;
}

void MakeJMPCode(LPBYTE lpJMPCode, LPVOID lpCodePoint)
{
	BYTE temp;
	WORD wHiWord = HIWORD(lpCodePoint);
	WORD wLoWord = LOWORD(lpCodePoint);
	WORD wCS;

	__asm						// ȡ��ǰ�x����q
	{
		push ax;
		push cs;		
		pop  ax;		
		mov  wCS, ax;//��ax��wCS,ʵ���ǰ�cs��wCS
		pop  ax;
		pop	 ax;//�ָ�ax(����ط���֪��ΪʲôҪ2��)
	};
	
	lpJMPCode[0] = 0xea;		// ���� JMP ָ��ęC���a�q
	//lpJMPCode[0] = 0xFF;

	temp = LOBYTE(wLoWord);		// -------------------------
	lpJMPCode[1] = temp;
	temp = HIBYTE(wLoWord);
	lpJMPCode[2] = temp;		// �����ַ�q�ڃȴ��е����飻
	temp = LOBYTE(wHiWord);		// Point: 0x1234
	lpJMPCode[3] = temp;		// �ȴ棺 4321
	temp = HIBYTE(wHiWord);
	lpJMPCode[4] = temp;		// -------------------------
	
	temp = LOBYTE(wCS);			// �����x����q
	lpJMPCode[5] = temp;
	temp = HIBYTE(wCS);
	lpJMPCode[6] = temp;
}

void HookWin32Api(LPAPIHOOKSTRUCT lpApiHook, int nSysMemStatus)
{
	
	DWORD  dwReserved;
	DWORD  dwTemp;
	BYTE   bWin32Api[5] = {0};

	//bWin32Api[0] = 0x00; 

	//TextOut(GetDC(GetActiveWindow()),2,15,"here",20);

	// ȡ�ñ��r�غ�����ַ�q
	if(lpApiHook->lpWinApiProc == NULL)
	{	
		lpApiHook->lpWinApiProc = (LPVOID)NHGetFuncAddress(lpApiHook->hInst, lpApiHook->lpszApiModuleName,lpApiHook->lpszApiName);
		if (lpApiHook->dwApiOffset != 0)
			lpApiHook->lpWinApiProc = (LPVOID)((DWORD)lpApiHook->lpWinApiProc + lpApiHook->dwApiOffset);
	}
	// ȡ�����������ַ�q
	if(lpApiHook->lpHookApiProc == NULL)
	{
		lpApiHook->lpHookApiProc = (LPVOID)NHGetFuncAddress(lpApiHook->hInst,
			lpApiHook->lpszHookApiModuleName,lpApiHook->lpszHookApiName);
	}
	// �γ� JMP ָ��q
	if (lpApiHook->HookApiFiveByte[0] == 0x00)
	{
		MakeJMPCode(lpApiHook->HookApiFiveByte, lpApiHook->lpHookApiProc);
	}

	if (!VirtualProtect(lpApiHook->lpWinApiProc, 16, PAGE_READWRITE,
			&dwReserved))
	{
		MessageBox(NULL, "VirtualProtect-READWRITE", NULL, MB_OK);
		return;
	}
	
	if (nSysMemStatus == HOOK_NEED_CHECK)
	{
		memcpy(lpApiHook->lpWinApiProc, (LPVOID)lpApiHook->HookApiFiveByte,BUFFERLEN);
	}
	else
	{
		if (lpApiHook->WinApiFiveByte[0] == 0x00)			// �Д��Ƿ��ѽ��r�ةq
		{
			// ��q
			// ��� API �����^�傀�ֹ��q
			memcpy(lpApiHook->WinApiFiveByte,(LPVOID)lpApiHook->lpWinApiProc,BUFFERLEN);
			// �Д��Ƿ����}�r�ةq(���Д���ݵ��^�傀�ֹ��Ƿ���γɵ�JMPָ��)
			if (memcmp((const char*)lpApiHook->WinApiFiveByte, 
				(const char*)lpApiHook->HookApiFiveByte, BUFFERLEN) == 0)
			{
				// �֏͂�ݵ��ֹ��q
				memcpy(lpApiHook->WinApiFiveByte,(LPVOID)lpApiHook->WinApiBakByte,BUFFERLEN);
			}
		}
		else
		{
			// �ǩq
			memcpy(bWin32Api,(LPVOID)lpApiHook->lpWinApiProc,BUFFERLEN);
		}

		if (memcmp((const char*)bWin32Api, (const char*)lpApiHook->HookApiFiveByte,
			BUFFERLEN) != 0)
		{
			// �� JMP ָ������ API �������^�q
			memcpy(lpApiHook->lpWinApiProc, (LPVOID)lpApiHook->HookApiFiveByte,BUFFERLEN);
		}
	}

	if (!VirtualProtect(lpApiHook->lpWinApiProc, 16, dwReserved, &dwTemp))
	{
		MessageBox(NULL, "VirtualProtect-RESTORE", NULL, MB_OK);
		return;
	}
	
}

void RestoreWin32Api(LPAPIHOOKSTRUCT lpApiHook, int nSysMemStatus)
{
	DWORD dwReserved;
	DWORD dwTemp;

	if (lpApiHook->lpWinApiProc == NULL)
		return;

	if (!VirtualProtect(lpApiHook->lpWinApiProc, 16, PAGE_READWRITE,
			&dwReserved))
	{
		MessageBox(NULL, "VirtualProtect-READWRITE", NULL, MB_OK);
		return;
	}
	memcpy(lpApiHook->lpWinApiProc,(LPVOID)lpApiHook->WinApiFiveByte,BUFFERLEN);
	if (!VirtualProtect(lpApiHook->lpWinApiProc, 16, dwReserved, &dwTemp))
	{
		MessageBox(NULL, "VirtualProtect-RESTORE", NULL, MB_OK);
		return;
	}
}