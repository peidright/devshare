// HookDll.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdlib.h>
#include "Hookapi.h"
#include "Exports.h"

APIHOOKSTRUCT g_TextOutAHook = {
	"gdi32.dll",
	"TextOutA",
	0,
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	NULL,
	"NHTextOutA",
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	0,
	{0XFF, 0X15, 0XFA, 0X13, 0XF3, 0XBF, 0X33}
};

APIHOOKSTRUCT g_TextOutWHook = {
	"gdi32.dll",
	"TextOutW",
	0,
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	NULL,
	"NHTextOutW",
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	0,
	{0XFF, 0X15, 0XFA, 0X13, 0XF3, 0XBF, 0X33}
};

APIHOOKSTRUCT g_ExtTextOutAHook = {
	"gdi32.dll",
	"ExtTextOutA",
	0,
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	NULL,
	"NHExtTextOutA",
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	0,
	{0XFF, 0X15, 0XFA, 0X13, 0XF3, 0XBF, 0X33}
};

APIHOOKSTRUCT g_ExtTextOutWHook = {
	"gdi32.dll",
	"ExtTextOutW",
	0,
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	NULL,
	"NHExtTextOutW",
	NULL,
	{0, 0, 0, 0, 0, 0, 0},
	0,
	{0XFF, 0X15, 0XFA, 0X13, 0XF3, 0XBF, 0X33}
};

//-------------------------------------------------------------------------
//������ת����HOOK����
void HookAllTextOut()
{
	HookWin32Api(&g_TextOutAHook, HOOK_CAN_WRITE);
	HookWin32Api(&g_TextOutWHook, HOOK_CAN_WRITE);
	HookWin32Api(&g_ExtTextOutAHook, HOOK_CAN_WRITE);
	HookWin32Api(&g_ExtTextOutWHook, HOOK_CAN_WRITE);
}
//-------------------------------------------------------------------------
//�ָ�HOOK����
void UnHookAllTextOut()
{
	RestoreWin32Api(&g_TextOutAHook, HOOK_NEED_CHECK);
	RestoreWin32Api(&g_TextOutWHook, HOOK_NEED_CHECK);
	RestoreWin32Api(&g_ExtTextOutAHook, HOOK_NEED_CHECK);
	RestoreWin32Api(&g_ExtTextOutWHook, HOOK_NEED_CHECK);
}


BOOL APIENTRY DllMain( HINSTANCE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	g_TextOutAHook.hInst = hModule;
	g_TextOutWHook.hInst = hModule;
	g_ExtTextOutAHook.hInst = hModule;
	g_ExtTextOutWHook.hInst = hModule;

	char* pszProcessId = (char*)malloc(10*sizeof(char));
	
    switch(ul_reason_for_call) { 
	case DLL_PROCESS_ATTACH: 
        HookAllTextOut();
		break;
	case DLL_PROCESS_DETACH:
		UnHookAllTextOut();
		break;
	case DLL_THREAD_ATTACH: 
	case DLL_THREAD_DETACH: 
        break; 
    }
	
    return TRUE;
}

