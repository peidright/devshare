int InjectDll( HANDLE hProcess );
int FreeDll( HANDLE hProcess,DWORD  hLibModule);

void enableDebugPriv();
DWORD getSpecifiedProcessId(const char* pszProcessName);