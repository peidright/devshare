#include "Trade.h"


Trade::Trade(void)
{
}


Trade::~Trade(void)
{
}
