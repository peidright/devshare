// CTP_Demo.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "Quote.h"
#include "Trade.h"
#include "string.h"
#include "iostream"

using namespace std;

CThostFtdcMdApi* md;
CThostFtdcTraderApi* api;
Quote* q = new Quote();
Trade* t = new Trade();

int nReq = 0;

int _tmain(int argc, _TCHAR* argv[])
{
	api = CThostFtdcTraderApi::CreateFtdcTraderApi("./tlog");
	api->RegisterSpi((CThostFtdcTraderSpi*)t);
	api->RegisterFront("tcp://ctpmn1-front1.citicsf.com:51205");
	api->Init();

	getchar();
	return 0;
}

//��trade.h�ļ��ж�ӦOn��������� {};ע��������
void Trade::OnFrontConnected()
{
	CThostFtdcReqUserLoginField f;
	memset(&f, 0, sizeof(f));
	strcpy(f.BrokerID, "1017");
	strcpy(f.UserID, "00000071");
	strcpy(f.Password, "123456");
	api->ReqUserLogin(&f, ++nReq);
}

void Trade::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cout << "trade:" << pRspInfo->ErrorMsg << endl;
	if (pRspInfo->ErrorID == 0)
	{
		CThostFtdcSettlementInfoConfirmField f;
		memset(&f, 0, sizeof(f));
		api->ReqSettlementInfoConfirm(&f, ++nReq);
	}
}

void Trade::OnRspSettlementInfoConfirm(CThostFtdcSettlementInfoConfirmField *pSettlementInfoConfirm, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	//��������
	md = CThostFtdcMdApi::CreateFtdcMdApi("./qlog");
	md->RegisterSpi((CThostFtdcMdSpi*)q);
	md->RegisterFront("tcp://ctpmn1-front1.citicsf.com:51213");
	md->Init();
}


//��quote.h�ļ��ж�ӦOn��������� {};ע��������

void Quote::OnFrontConnected()
{
	CThostFtdcReqUserLoginField f;
	memset(&f, 0, sizeof(f));
	strcpy(f.BrokerID, "1017");
	strcpy(f.UserID, "00000071");
	strcpy(f.Password, "123456");
	md->ReqUserLogin(&f, ++nReq);
};

void Quote::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cout << "mq:" << pRspInfo->ErrorMsg << endl;
	char inst[32];
	strcpy(inst, "cu1401");
	char*ppInst[1];
	ppInst[0] = inst;
	md->SubscribeMarketData(ppInst, 1);
}

void Quote::OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData)
{
	if (pDepthMarketData->LastPrice == 49730)
	{
		//�����ֶ����������,���е���
		CThostFtdcInputOrderField f;
		memset(&f, 0, sizeof(f));
		strcpy(f.InstrumentID, pDepthMarketData->InstrumentID);
		strcpy(f.BrokerID, "1017");
		strcpy(f.InvestorID, "00000071");
		f.Direction = THOST_FTDC_D_Buy;
		f.CombOffsetFlag[0] = THOST_FTDC_OF_Open;
		f.LimitPrice = pDepthMarketData->LastPrice;
		f.VolumeCondition = THOST_FTDC_VC_AV;
		f.VolumeTotalOriginal = 1;
		api->ReqOrderInsert(&f, ++nReq);
	}
}

void Trade::OnRspOrderInsert(CThostFtdcInputOrderField *pInputOrder, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	cout << pRspInfo->ErrorMsg << endl;
}

void Trade::OnRtnOrder(CThostFtdcOrderField *pOrder)
{
	cout << pOrder->InsertTime << endl;
}