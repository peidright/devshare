#include "Quote.h"


Quote::Quote(void)
{
}


Quote::~Quote(void)
{
}
