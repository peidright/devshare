/***************************************************************
 * Name:      CTPTradingApp.h
 * Purpose:   Defines Application Class
 * Author:    ���� (hubert28@qq.com)
 * Created:   2012-07-03
 * Copyright: ���� ()
 * License:
 **************************************************************/

#ifndef CTPTRADINGAPP_H
#define CTPTRADINGAPP_H

#include <wx/app.h>

class CTPTradingApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // CTPTRADINGAPP_H
